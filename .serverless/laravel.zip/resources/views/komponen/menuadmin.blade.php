<!-- Heading -->
<div class="sidebar-heading">
    Transaction Data
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link" href="/listorder">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>List Order</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Master Data
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link" href="/service">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Service</span></a>
</li>
