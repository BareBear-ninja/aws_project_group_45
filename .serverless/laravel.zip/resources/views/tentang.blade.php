@extends("layout/aplikasi")

@section("content")
<h1>tentang</h1>
@endsection
